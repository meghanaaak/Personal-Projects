// const name = "meghana";

// console.log(name);
// console.log(global);
// setTimeout(() => {
//     console.log("in the time");
//     clearInterval(int);
// },3000);

// const int = setInterval(() => {
//     console.log('in the interval');
// },1000);

// console.log(__dirname);
// console.log(__filename);
const people = ['meghana', 'sreeja', 'archana'];
const ages = [23,1, 9];
// console.log(people);
module.exports = {people, ages};