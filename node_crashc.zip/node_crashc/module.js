// const {people, ages} = require('./test');
// console.log(people, ages);

const fs = require('fs');
// fs.readFile('./txt.txt', (err, data) => {
//     if(err){
//         console.log("error");
//     }
//     console.log(data.toString());

// })

// fs.writeFile('./txt1.txt', 'hello again', () => {
//     console.log("file is written");
// });

// fs.mkdir('./dir', (err) => {
//     if(err){
//         console.log("error");
//     }
// })
// if( fs.existsSync('./dir'))
// {
//     fs.rmdir('./dir',(err) => {
//         if(err){
//             console.log("error in removing");
//         }
//         console.log("dir removed");
//     })
// }

// if(fs.existsSync('./txt1.txt'))
// {
//     fs.unlink('./txt1.txt', (err)=> {
//        if(err){ console.log(err);}
//        console.log("file removed");
//     })
// }

const readstream = fs.createReadStream('./txt.txt', {encoding: 'utf-8'});
const writestream = fs.createWriteStream('./txt2.txt');
// readstream.on('data', (chunk)=>{
//     console.log("-----NEW STREAM-----");
//     console.log(chunk);
// })
readstream.pipe(writestream);