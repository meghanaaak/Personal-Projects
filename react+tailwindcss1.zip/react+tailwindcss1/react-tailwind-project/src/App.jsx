
import './App.css'
import Features from './components/Features'
import Home from './components/Home'
import Navbar from './components/Navbar'
import About from './components/About'
import Pricing from './components/Pricing'
import Footer from './components/Footer'

function App() {
 

  return (
    <>
      <Navbar/>
      <Home/>
      <Features/>
      <About/>
      <Pricing/>
      <Footer/>
    </>
  )
}

export default App
