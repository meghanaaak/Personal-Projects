import banner from '../assets/banner.png'
import {motion} from "framer-motion"
import { fadeIn } from '../../variants'

const Home = () => {
  return (
    <div className="md:px-14 p-4 mt-24 max-w-screen-2xl mx-auto " id='Home'>
        <div className='gradientbg rounded-xl rounded-br-[80px] '>
            <div className='flex flex-col md:flex-row-reverse justify-between items-center gap-10 md:p-9 px-4 py-9'>

                <motion.div
                variants={fadeIn("down",0.7)}
                initial="hidden"
                whileInView={"show"}
                viewport={{once:false, amount:0.7}}
                >
                    <img src={banner} alt=""  className='lg:h-[386px]'/>
                </motion.div>
                <motion.div 
                variants={fadeIn("up",0.7)}
                initial="hidden"
                whileInView={"show"}
                viewport={{once:false, amount:0.7}}
                className="md:w-3/5">
                    <h2 className='text-4xl md:text-7xl font-bold text-white mb-6 leading-relaxed'>Develop your skills without diligence</h2>
                    <p className='text-[#EBEBEB] font-normal text-xl mb-8'>A good example of a paragraph contains a topic sentence, details and a 
                        conclusion. There are many different kinds of animals that live in China.</p>
                        <div className='space-x-5'>
                            <button className='py-3 px-6 bg-secondary rounded font-semibold text-white hover:bg-indigo-600 transition-all duration-300'>Get Started</button>
                            <button className='py-3 px-6 bg-secondary rounded font-semibold text-white hover:bg-indigo-600 transition-all duration-300'>Discount</button>
                        </div>
                </motion.div>
                
            </div>
        </div>
    </div>
  )
}

export default Home