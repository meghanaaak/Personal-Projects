import { useState } from "react"
import green from '../assets/green.png'
import {motion} from "framer-motion"
import { fadeIn } from '../../variants'

const Pricing = () => {
    const [isYearly, setIsYearly] = useState(false)

    const packages = [
        {name: 'Start',monthlyprice: 19, yearlyprice: 199, description:"A common form of Lorem ipsum reads: Lorem ipsum dolor sit amet, consectetur adipiscing elit.",green: green},
        {name: 'Advance',monthlyprice: 39, yearlyprice: 399, description:"A common form of Lorem ipsum reads: Lorem ipsum dolor sit amet, consectetur adipiscing elit.",green: green},
        {name: 'Premium',monthlyprice: 59, yearlyprice: 599, description:"A common form of Lorem ipsum reads: Lorem ipsum dolor sit amet, consectetur adipiscing elit.",green: green},
    ]
  return (
    <div className="md:px-14 p-4 mx-auto max-w-s py-10" id="pricing">
        <div className="text-center">
            <h2 className="text-primary font-extrabold md:text-5xl text-3xl pt-9 mb-2">Here are all our plans</h2>
            <p className="text-teritiary md:w-1/3 mx-auto px-3">A simple paragraph is comprised of three major components. The which is often a declarative sentence.</p>

            <div className="mt-16">
            <label htmlFor="toggle" className="inline-flex items-center cursor-pointer">
                <span className="mr-8 text-2xl font-semibold text-primary">Monthly</span>
                <div className="w-14 h-6 bg-gray-300 rounded-full">
                    <div className={`w-6 h-6 rounded-full transition duration-200 ease-in-out ${isYearly ?"bg-primary ml-8" :"bg-gray-500" }`}>
                    </div>
                </div>
                <span className="ml-8 text-2xl font-semibold text-primary">Yearly</span>
            </label>
            <input type="checkbox" id="toggle" className="hidden" checked={isYearly} onChange={() => setIsYearly(!isYearly)}></input>
            </div>
        </div>

        <motion.div
        variants={fadeIn("up",0.3)}
        initial="hidden"
        whileInView={"show"}
        viewport={{once:false, amount:0.5}}
        className="grid sm:grid-cols-2 lg:grid-cols-3 gap-10 mt-20 md:w-11/12 mx-auto">
            {
                packages.map((pkg,index) => <div key={index} className="border py-10 md:px-6 px-4 rounded-lg shadow-3xl">
                    <h3 className="text-3xl font-bold text-center text-primary">{pkg.name}</h3>
                    <p className="text-teritiary text-center my-5">{pkg.description}</p>
                    <p className="mt-5 text-center text-secondary text-4xl">
                        {isYearly ? `$${pkg.yearlyprice}` : `$${pkg.monthlyprice}`} <span className="text-base text-teritiary font-small">/{isYearly ? 'year' : 'month'}</span>
                    </p>
                    <ul className="mt-6 space-y-2">
                        <li className="flex gap-3 items-center"><img src={pkg.green} alt="" className="w-4 h-4" />Videos of Lessons</li>
                        <li className="flex gap-3 items-center"><img src={pkg.green} alt="" className="w-4 h-4" />Homework check</li>
                        <li className="flex gap-3 items-center"><img src={pkg.green} alt="" className="w-4 h-4" />Additional practical task</li>
                        <li className="flex gap-3 items-center"><img src={pkg.green} alt="" className="w-4 h-4" />Monthly conferences </li>
                        <li className="flex gap-3 items-center"><img src={pkg.green} alt="" className="w-4 h-4" />Personal advice from teachers</li>
                    </ul>
                    <div className=" w-full mx-auto  mt-8 flex items-center justify-center">
                        <button  className='py-3 px-6 bg-secondary rounded font-semibold text-white hover:bg-indigo-600 transition-all duration-300'>Get Started</button>
                    </div>
                </div>)
            }
        </motion.div>

        
    </div>
  )
}

export default Pricing